﻿/*
 * Check out the Testing Important Examples object 
 * in the "Testing - All" scene. 
 * 
 * After clicking on the object, look at the Inspector
 * to see what this stuff does.
 * 
 * https://unity3d.college/2017/05/22/unity-attributes/
 * 
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestingImportantExamples : MonoBehaviour {

    

    [Tooltip("Choose between 0 and 100")]   // Hover over the variable in the Inspector for a tooltip description
    [Range(0, 100)]                         // Range can be in int or float format
    public int intWithinRange;

    [Tooltip("Choose between -10.0 and 20.0")]
    [Range(-10f, 20f)]
    public float floatWithinRange;

    [Space]                                 // Adds a space between variables in the Inspector
    public float thing1;
    public float thing2;

    [HideInInspector]                       // Variable will still be public, but you can't see or change it in the Inspector
                                            // If you want, you can first set the variable in the Inspector, then add
                                            // [HideInInspector] later. This way, you can set then hide it to prevent
                                            // changing it again if it's where you want it.
    public float thing3;

    [Header("Player Health")]               // Makes a group for the set of variables below it

    public float health;

    [SerializeField]                        // Makes private variables visible and alterable within the Inspector
    private float shieldAmount;


    [Header("Player Damage")]

    public float attackDamage;

    public float damageMultiplier;

    [Header("Spaced player bools")]                // Be careful - this will add a header between each item
    public bool canAttack, canMove, invulnerable;

    [Header("Grouped player bools")]
    public bool isOnFire;
    public bool isPoisoned;
    public bool isHallucinating;

    
    public void AllowControls(bool yesOrNo)
    {
        AllowAttack(yesOrNo);       // Hover over these method names and you'll get their descriptions
        AllowMovement(yesOrNo);     
    }

                                                 // To make a description for a method, add three slashes /// before a method
    /// <summary>
    /// Sets whether attacking is allowed
    /// </summary>
    /// <param name="setAttack">New condition setting the ability to attack</param>
    private void AllowAttack(bool setAttack)     // Hover over setAttack and it'ss tell you what it does
    {
        canAttack = setAttack;
    }

    /// <summary>
    /// Sets whether moving is allowed
    /// </summary>
    /// <param name="setMovement"></param>
    private void AllowMovement(bool setMovement)
    {
        canMove = setMovement;
    }

    

    /// <summary>
    /// Attack finder
    /// </summary>
    /// <returns>whether player can attack</returns>    // Describes what it returns
    public bool GetAttack()
    {
        return canAttack;
    }
    
}

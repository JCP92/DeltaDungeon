﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerationManualManager : MonoBehaviour
{
    #region variables

    // The base dimensions of a room
    protected int roomWidth = 16;
    protected int roomHeight = 16;

    // Base dimensions of n*n room sizes
    protected int roomSizeDimensions = 16;

    [Header("Wall/Ground Materials")]
    public Material wallMaterial;
    public Material GroundMaterial;

    [Header("Room Sizes")]
    [Tooltip("Used to set specific room dimension multipliers")]
    [SerializeField]
    protected bool debugRoomSizes = false;
    [Tooltip("Multiplier for room width * 16 units")]
    public int roomWidthMultiplier = 1;
    [Tooltip("Multiplier for room height * 16 units")]
    public int roomHeightMultiplier = 1;

    [Header("Room Sizes - Randomized")]
    [SerializeField]
    protected bool randomizeRoomHeight;
    [SerializeField]
    protected int minRoomHeight = 1;
    [SerializeField]
    protected int maxRoomHeight = 1;

    [Space]
    [SerializeField]
    protected bool randomizeRoomWidth;
    [SerializeField]
    protected int minRoomWidth = 1;
    [SerializeField]
    protected int maxRoomWidth = 1;

    [Header("Debug Player")]
    [Space]
    [Tooltip("Spawns player for map testing")]
    [SerializeField]
    protected bool debugPlayer;
    public GameObject player;
    public GameObject testCamera;

    [Header("Debug Level Layout")]
    [SerializeField]
    [Tooltip("Choose level to create")]
    protected bool debugChooseLayout;
    public int chosenLayout = 1;

    #endregion


    // Update is called once per frame
    void Start()
    {
        ChooseGrid();
        SetRoomDimensions();
    }


    /// <summary>
    /// Decide which map layout to use
    /// </summary>
    protected void ChooseGrid()
    {
        if (!debugChooseLayout)
        {
            // Max = # of maps + 1 (Upeer int isn't inclusive)
            chosenLayout = Random.Range(1, 11);
        }

        switch (chosenLayout)
        {
            case 1:
                GenerateGrid001();
                break;
            case 2:
                GenerateGrid002();
                break;
            case 3:
                GenerateGrid003();
                break;
            case 4:
                GenerateGrid004();
                break;
            case 5:
                GenerateGrid005();
                break;
            case 6:
                GenerateGrid006();
                break;
            case 7:
                GenerateGrid007();
                break;
            case 8:
                GenerateGrid008();
                break;
            case 9:
                GenerateGrid009();
                break;
            case 10:
                GenerateGrid010();
                break;
            default:
                GenerateGrid001();
                break;
        }
    }

    #region Room Dimension Setters

    /// <summary>
    /// Sets new multipliers for room width and height
    /// </summary>
    /// <param name="width"></param>
    /// <param name="height"></param>
    protected void SetRoomDimensionMultipliers(int width, int height)
    {
        roomWidthMultiplier = width;
        roomHeightMultiplier = height;
    }


    /// <summary>
    /// Sets new room dimensions, uses base width/height * multipliers.
    /// </summary>
    protected void SetRoomDimensions()
    {
        // Set room sizes
        roomWidth = roomSizeDimensions * roomWidthMultiplier;
        roomHeight = roomSizeDimensions * roomHeightMultiplier;
    }

    #endregion

    /// <summary>
    /// Create Zelda-like setup of dungeon
    /// </summary>
    /// <param name="grid"></param>
    protected void GenerateBigRooms(int[][] grid)
    {
        GenerateGround(grid);

        GenerateWalls(grid);
    }

    /// <summary>
    /// Starting position of player
    /// </summary>
    /// <param name="playerPosition"></param>
    protected void MakePlayer(Vector3 playerPosition)
    {
        GameObject playerClone = Instantiate(player);
     
        playerClone.transform.position = playerPosition;

        // Disable Main Camera (it doesn't track player)
        GameObject mainCam = GameObject.FindGameObjectWithTag("MainCamera");
        mainCam.SetActive(false);
        
        // Enable Tracking Camera, set player to be tracked
        GameObject camera = Instantiate(testCamera);
        TestingCameraController camControl = camera.GetComponent<TestingCameraController>();
        camControl.player = GameObject.FindGameObjectWithTag("Player");
    }


    /// <summary>
    /// Builds the ground pieces using planes
    /// </summary>
    /// <param name="grid"></param>
    protected void GenerateGround(int[][] grid)
    {
        for (int row = grid.Length - 1; row > 0; row--)
        {
            int rowOffset = grid.Length - 1 - row;

            // Check all but the last elements - these will be zero
            for (int column = 1; column < grid[row].Length - 1; column++)
            {
                if (grid[row][column] != 0)
                {
                    GameObject plane = GameObject.CreatePrimitive(PrimitiveType.Plane);

                    plane.GetComponent<Renderer>().material = new Material(GroundMaterial);

                    plane.transform.localScale = new Vector3(1.6f * roomWidthMultiplier, 1, 1.6f * roomHeightMultiplier);

                    // Make sure to keep switched row/column here to fix alignment (won't rotate)
                    plane.transform.position = new Vector3(column * roomWidth, 0, rowOffset * roomHeight);

                    plane.layer = LayerMask.NameToLayer("Floor"); ;

                    //quad.transform.rotation = Quaternion.Euler(90f, 0, 0);    // Keep for later in case of plane/quad swap
                }
            }
        }
    }


    /// <summary>
    /// Creates and returns basic walls (Cubes)
    /// </summary>
    /// <returns></returns>
    protected GameObject CreateWallPiece()
    {
        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);

        wall.GetComponent<Renderer>().material = new Material(wallMaterial);

        return wall;
    }
    

    protected void GenerateWalls(int[][] grid)
    {
        // Amount to shift wall positions - will end on edge of planes
        float xWallOffset = (roomWidth / 2) + 0.5f;
        float yWallOffset = (roomHeight / 2) + 0.5f;


        for (int row = grid.Length - 1; row > 0; row--)
        {
            int rowOffset = grid.Length - 1 - row;

            // Check all but the last elements - these will be zero
            for (int column = 1; column < grid[row].Length - 1; column++)
            {
                //int columnOffset = grid[row].Length - 1 - column;                                     // TO-DO: Maybe used later to fix wall gaps
                //int biggerWall = 0;

                // If the room is occupied, check for empty space next to it
                if (grid[row][column] != 0)
                {
                    // Generate Left Walls
                    if (grid[row][column] != 0 && grid[row][column - 1] == 0)
                    {
                        GameObject wall = CreateWallPiece();

                        wall.transform.localScale = new Vector3(1, 2, roomHeight);
                        
                        wall.transform.position = new Vector3(column * roomWidth - xWallOffset, 1, rowOffset * roomHeight);
                    }
                    
                    // Generate Right Walls
                    if (grid[row][column] != 0 && grid[row][column + 1] == 0)
                    {
                        GameObject wall = CreateWallPiece();

                        wall.transform.localScale = new Vector3(1, 2, roomHeight);

                        wall.transform.position = new Vector3(column * roomWidth + xWallOffset, 1, rowOffset * roomHeight);
                    }
                    
                    // Generate Bottom Walls
                    if (grid[row][column] != 0 && grid[row - 1][column] == 0)
                    {
                        GameObject wall = CreateWallPiece();

                        wall.transform.localScale = new Vector3(1, 2, roomWidth);

                        wall.transform.rotation = Quaternion.Euler(0, 90, 0);

                        // wall.transform.position = new Vector3(rowOffset * 7 - 1, 0, (column * 7) - 1);
                        wall.transform.position = new Vector3(column * roomWidth, 1, rowOffset * roomHeight + yWallOffset);
                    }
                
                    // Generate Top Walls
                    if (grid[row][column] != 0 && grid[row + 1][column] == 0)
                    {
                        GameObject wall = CreateWallPiece();

                        wall.transform.localScale = new Vector3(1, 2, roomWidth);

                        wall.transform.rotation = Quaternion.Euler(0, 90, 0);

                        // wall.transform.position = new Vector3(rowOffset * 7 - 1, 0, (column * 7) - 1);
                        wall.transform.position = new Vector3(column * roomWidth, 1, rowOffset * roomHeight - yWallOffset);
                    }
                }

                // Make player in specified room if degugging the level layout
                // Move into its own method later
                if(grid[row][column] == 7)
                {
                    if (debugPlayer)
                    {
                        Vector3 position = new Vector3(rowOffset * roomWidth, 0, column * roomHeight);
                        MakePlayer(position);
                    }
                }
            }
        }
    }


    #region Generate Grids

    /// <summary>
    /// 0 == open room, 1 == occupied room, 7 == player start room
    /// </summary>
    private void GenerateGrid001()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }
        
        SetRoomDimensions();

        // 10x10 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid002()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 6x6 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 1, 1, 1, 0, 0, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0},
            new int[] { 0, 1, 0, 1, 1, 1, 0, 0},
            new int[] { 0, 1, 0, 1, 1, 0, 0, 0},
            new int[] { 0, 0, 0, 1, 0, 0, 0, 0},
            new int[] { 0, 0, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 0, 1, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid003()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 6x6 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 2, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 1, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid004()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid005()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid006()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid007()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid008()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid009()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid010()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    #endregion


    #region Room Dimension Templates

    /*
     
    // For altering width/height settings of room - can place in GenerateGrid()
    // methods before building level
    {
    int newRoomWidth = Random.Range(1,5);
    int newRoomHeight = Random.Range(1,5);

    SetNewRoomDimensions(newRoomWidth, newRoomHeight);
    }

    // 5x5 level
    int[][] level =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, },
            new int[] { 0, 0, 0, 0, 0, 0, 0, }
        };


    // 6x6 level
    int[][] level =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0}
        };

    
    // 7x7 level
    int[][] level =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };

    
    // 8x8 level
    int[][] level =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };
    
    
    // 9x9 level
    int[][] level =
    {
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };


    // 10x10 level
    int[][] level =
    {
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };
    

    // 11x11 level
    int[][] level =
    {
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };
    

    // 12x12 level
    int[][] level =
    {
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };


    */

    #endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerationManual_Jackson : LevelGenerationManualManager {

    // Update is called once per frame
    void Start()
    {
        ChooseGrid();
        SetRoomDimensions();
    }

    /// <summary>
    /// Decide which map layout to use
    /// </summary>
    protected new void ChooseGrid()
    {
        if (!debugChooseLayout)
        {
            // Max = # of maps + 1 (Upeer int isn't inclusive)
            chosenLayout = Random.Range(1, 11);
        }

        switch (chosenLayout)
        {
            case 1:
                GenerateGrid001();
                break;
            case 2:
                GenerateGrid002();
                break;
            case 3:
                GenerateGrid003();
                break;
            case 4:
                GenerateGrid004();
                break;
            case 5:
                GenerateGrid005();
                break;
            case 6:
                GenerateGrid006();
                break;
            case 7:
                GenerateGrid007();
                break;
            case 8:
                GenerateGrid008();
                break;
            case 9:
                GenerateGrid009();
                break;
            case 10:
                GenerateGrid010();
                break;
            default:
                GenerateGrid001();
                break;
        }
    }

    #region Generate Grids

    /// <summary>
    /// 0 == open room, 1 == occupied room, 7 == player start room
    /// </summary>
    protected void GenerateGrid001()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 10x10 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0},
            new int[] { 0, 1, 7, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid002()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 6x6 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 1, 1, 1, 0, 0, 1, 0},
            new int[] { 0, 1, 1, 1, 0, 1, 1, 0},
            new int[] { 0, 1, 0, 1, 1, 1, 0, 0},
            new int[] { 0, 1, 0, 1, 1, 0, 0, 0},
            new int[] { 0, 0, 0, 1, 0, 0, 0, 0},
            new int[] { 0, 0, 1, 1, 1, 1, 1, 0},
            new int[] { 0, 1, 1, 0, 0, 0, 1, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid003()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 6x6 level
        int[][] grid =
        {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 2, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 1, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0}
        };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid004()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid005()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid006()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid007()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid008()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid009()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    private void GenerateGrid010()
    {
        // Set room width/height multipliers
        if (debugRoomSizes)
        {
            SetRoomDimensionMultipliers(roomWidthMultiplier, roomHeightMultiplier);
        }
        else
        {
            // If not randomized, set custom level width and height
            int newRoomWidth = 1;
            int newRoomHeight = 1;

            if (randomizeRoomWidth)
                newRoomWidth = Random.Range(minRoomWidth, maxRoomWidth);

            if (randomizeRoomHeight)
                newRoomHeight = Random.Range(minRoomHeight, maxRoomHeight);

            SetRoomDimensionMultipliers(newRoomWidth, newRoomHeight);
        }

        SetRoomDimensions();

        // 8x8 level
        int[][] grid =
            {
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
       };

        GenerateBigRooms(grid);
    }

    #endregion

}

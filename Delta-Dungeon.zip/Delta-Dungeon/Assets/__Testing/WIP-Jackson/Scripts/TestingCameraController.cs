﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestingCameraController : MonoBehaviour {

    public GameObject player;

    private Vector3 offset;

    [Header("Camera Distances")]
    [Tooltip("Height above player")]
    public float cameraHeight = 30;
    [Tooltip("Distance above/below player")]
    public float cameraZOffset = -2;

    void Start()
    {
        //offset = transform.position - player.transform.position;
        offset = new Vector3(0, cameraHeight, cameraZOffset);
    }

    void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
}

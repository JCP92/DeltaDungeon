﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestingRoomSizeGenerator : MonoBehaviour {

    public GameObject enemy;
    public float enemyChance = 0.05f;

    [HideInInspector]
    public GameObject groundType1;
    [HideInInspector]
    public GameObject groundType2;

    [Space]
    [HideInInspector]
    public GameObject wall;

    [Space]
    public int leftRoomWidth = 9;
    public int leftRoomHeight = 9;

    [Space]
    public int rightRoomWidth = 12;
    public int rightRoomHeight = 12;

    private bool groundTypeSwitcher;
    private int xOffset = 3;
    private int zOffset = 3;

    // Use this for initialization
    void Awake()
    {
        groundTypeSwitcher = false;
    }

    private void Start()
    {
        GenerateLeftRoom();
        GenerateRightRoom();
        
    }

    void GenerateLeftRoom()
    {
        ZWalls( -leftRoomWidth - xOffset, -xOffset, leftRoomHeight);

        // Outside X Wall
        XWalls(-zOffset + 1, leftRoomHeight - 2, -leftRoomWidth-zOffset);

        // Inside X Wall
        XWalls(zOffset+1, leftRoomHeight-zOffset+1 , - xOffset);

        Ground(leftRoomWidth, leftRoomHeight, -leftRoomWidth - xOffset, -xOffset);
    }

    void GenerateRightRoom()
    {
        ZWalls(xOffset+1, rightRoomWidth + xOffset, rightRoomHeight);

        // Outside X Wall
        XWalls(-xOffset, rightRoomHeight - 2, rightRoomWidth + xOffset);

        // Inside X Wall
        XWalls(zOffset + 1, rightRoomHeight - zOffset + 1, xOffset);

        groundTypeSwitcher = !groundTypeSwitcher;

        Ground(rightRoomWidth, rightRoomHeight, xOffset, -zOffset);
    }

    void ZWalls(int from, int to, int height)
    {
        for(int leftSide = from; leftSide < to; leftSide++)
        {
            GameObject wallClone = Instantiate(wall);

            wallClone.transform.position = new Vector3(leftSide, 1, -3);

            GameObject wallClone2 = Instantiate(wall);

            wallClone2.transform.position = new Vector3(leftSide, 1, height -3);
        }
    }

    void XWalls(int from, int to, int xPos)
    {
        for(int next = from; next < to; next++)
        {
            GameObject wallClone = Instantiate(wall);

            wallClone.transform.position = new Vector3(xPos, 1, next);
        }
    }

    void Ground(int width, int height, int startXPos, int startYPos)
    {
        for (int xPos = 1; xPos < width; xPos++)
        {
            for (int yPos = 1; yPos < height; yPos++)
            {
                GameObject groundTypeClone;

                if (groundTypeSwitcher)
                {
                    groundTypeClone = Instantiate(groundType1);
                }
                else
                    groundTypeClone = Instantiate(groundType2);

                groundTypeSwitcher = !groundTypeSwitcher;

                groundTypeClone.transform.position = new Vector3(startXPos + xPos, -0.5f,  startYPos + yPos);

                GenerateEnemy(startXPos + xPos, startYPos + yPos);
            }

            if ((width - 1) % 2 == 0)
                groundTypeSwitcher = !groundTypeSwitcher;

            if (((width - 1) % 2) != ((height - 1) % 2))
                groundTypeSwitcher = !groundTypeSwitcher;

            
        }
    }

    void GenerateEnemy(int xPos, int zPos)
    {
        float randomNumber = Random.Range(0f, 1f);

        if ( randomNumber < enemyChance)
        {
            GameObject enemyClone = Instantiate(enemy);
            enemyClone.transform.position = new Vector3(xPos, 0, zPos);
        }



    }
}

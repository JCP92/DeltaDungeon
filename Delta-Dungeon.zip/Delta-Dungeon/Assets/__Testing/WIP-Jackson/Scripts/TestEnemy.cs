﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestEnemy : MonoBehaviour {

    
    [Tooltip("Speed to chase the player")]
    public float speed = 4f;

    [Space]
    [Tooltip("Hit Points")]
    public float hitPoints = 4f;
    

    [Space]
    [Tooltip("Distance to player before exploding")]
    public float proximityExplode = 2f;

    [Space]
    [Tooltip("Explosion particle system")]
    public GameObject explosion;
    
    // Check if player enters the mine bounds
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
            StartCoroutine(FollowPlayer(other.transform));
    }

    /// <summary>
    /// Follow the player and explode
    /// </summary>
    /// <param name="target"></param>
    /// <returns></returns>
    private IEnumerator FollowPlayer(Transform target)
    {
        float distance;

        while (transform.position != target.position)
        {
            transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

            distance = Vector3.Distance(transform.position, target.position);

            if (distance < proximityExplode)
                Explode();

            yield return null;
        }

        
    }

    /// <summary>
    /// Deal damage to enemy
    /// </summary>
    /// <param name="damage"></param>
    public void Damage(float damage)
    {
        hitPoints -= damage;

        if (hitPoints <= 0)
            Explode();
    }

    /// <summary>
    /// Kaboom
    /// </summary>
    private void Explode()
    {
        Instantiate(explosion, transform.position, transform.rotation);

        Destroy(gameObject);
    }
}

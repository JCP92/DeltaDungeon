﻿/* * Modified from the Unity Survival Shooter tutorial * https://unity3d.com/learn/tutorials/projects/survival-shooter/player-character?playlist=17144 *  *  */



using System.Collections;using System.Collections.Generic;using UnityEngine;public class TestingPlayerWeapon : MonoBehaviour {    public GameObject player;    private Vector3 playerPosition;        public GameObject bullet;    public Transform bulletLocation;    public float bulletSpeed;    Rigidbody playerRigidbody;          // Reference to the player's rigidbody.
    int floorMask;                      // A layer mask so that a ray can be cast just at gameobjects on the floor layer.
    float camRayLength = 100f;          // The length of the ray from the camera into the scene.



    // Use this for initialization
    void Awake () {
        // Create a layer mask for the floor layer.
        floorMask = LayerMask.GetMask("Floor");

        // Set up references.
        playerRigidbody = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Shoot();
        }
    }

    // Update is called once per frame
    void FixedUpdate () {        Turning();	}    // Modified from "Turret" script in Turret Trouble game    void Shoot()
    {
        Vector3 direction = bulletLocation.transform.position - transform.position;
        direction.Normalize();      // Normalize will fix bullet speed - gives magnitude of 1


        GameObject bulletClone = (GameObject)Instantiate(bullet, bulletLocation.transform.position, bulletLocation.transform.rotation * Quaternion.Euler(90,-90,0));

        Rigidbody rb = bulletClone.GetComponent<Rigidbody>();

        rb.velocity = direction * bulletSpeed;
        
    }    void Turning()    {        transform.position = player.transform.position;        // Create a ray from the mouse cursor on screen in the direction of the camera.        Ray camRay = Camera.main.ScreenPointToRay(Input.mousePosition);        // Create a RaycastHit variable to store information about what was hit by the ray.        RaycastHit floorHit;        // Perform the raycast and if it hits something on the floor layer...        if (Physics.Raycast(camRay, out floorHit, camRayLength, floorMask))        {            // Create a vector from the player to the point on the floor the raycast from the mouse hit.            Vector3 playerToMouse = floorHit.point - transform.position;                        // Ensure the vector is entirely along the floor plane.            playerToMouse.y = 0f;            // Create a quaternion (rotation) based on looking down the vector from the player to the mouse.            Quaternion newRotation = Quaternion.LookRotation(playerToMouse);            newRotation *= Quaternion.Euler(0, -90, 0); // this adds a -90 degrees Y rotation and fixes the weapon direction

            // Set the player's rotation to this new rotation.
            playerRigidbody.MoveRotation(newRotation);        }    }}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestingBulletDamage : MonoBehaviour {

    [Tooltip("Damage dealt by weapon")]
    public float damage = 1f;

    // Check if bullet hits an enemy or boundary
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            TestEnemy enemy = other.GetComponent<TestEnemy>();
            enemy.Damage(damage);

            Explode();
        }
        else if (other.CompareTag("Walls"))
            Explode();
    }

    /// <summary>
    /// Destroy the bullet
    /// </summary>
    private void Explode()
    {
        Destroy(gameObject);
    }
}

﻿/*
 * Keeps track of public variables used for conditional checking
 * 
 */

using UnityEngine;
using System.Collections;

public class PlayerManager : MonoBehaviour
{
    [Tooltip("Player's life amount")]
    [SerializeField]
    protected float life;

    [Space]
    [Tooltip("Player's damage offset (toughness / % damage taken)")]
    [SerializeField]
    protected float harmOffset;

    [Space]
    [Tooltip("Player's shield amount (depletable)")]
    [SerializeField]
    protected float shieldAmount;

    [HideInInspector]
    public bool canAttack = false;              // Can player jump?
    [HideInInspector]
    public bool canMove = false;                // Can player move?


    private float stunTimeLeft;                 // Stun time remaining

    //private Animator anim;                      // Reference to the player's animator component.

    // Disables player until fully faded in
    void Awake()
    {
        // For accessing Player Animator
        //anim = gameObject.GetComponent<Animator>();
    }

    #region Late Updates

    void LateUpdate()
    {
        // Anims set after all other calculations
        // This will fix delay errors with player animations
        setAnims();
    }

    // Sets anims in this script
    void setAnims()
    {

    }

    #endregion


    #region Damage player

    public void DamagePlayer(float damage)
    {
        // Compare damage dealt to shield amount, harmOffset
    }


    // Life is for the living :,o(
    protected void Die()
    {

    }

    #endregion

    #region Stun Player

    /// <summary>
    /// Stun player for the set amount of time
    /// </summary>
    /// <param name="stunTime"></param>
    public void StunPlayer(float stunTime)
    {
        if (stunTimeLeft <= 0.0)
            StartCoroutine(StunPlayerHelper(stunTime));
    }

    /// <summary>
    /// Stun player for set amount of time
    /// </summary>
    protected IEnumerator StunPlayerHelper(float stunTime)
    {
        // Check if the player is already stunned
        
            AllowControl(false);

            // Instantiate (stun effect)

            while (stunTimeLeft > 0)
            {
                stunTimeLeft -= Time.deltaTime;

                yield return null;
         }

        // Disable (stun effect)

        stunTimeLeft = 0;

        AllowControl(true);
        
    }

    #endregion


    #region Change Controls
    
    /// <summary>
    /// Sets ability to move and jump
    /// </summary>
    public void AllowControl(bool setting)
    {
        canMove = canAttack = setting;
    }


    /// <summary>
    /// Sets ability to Attack
    /// </summary>
    /// <param name="setting"></param>
    public void AllowAttack(bool setting)
    {
        canAttack = setting;
    }


    /// <summary>
    /// Sets ability to move
    /// </summary>
    /// <param name="setting"></param>
    public void AllowMovement(bool setting)
    {
        canMove = setting;
    }

    #endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyByTime : MonoBehaviour {

	/// <summary>
    /// Destroys after a set time
    /// </summary>
	void Start () {
        Destroy(gameObject, 2f);
	}
	
}

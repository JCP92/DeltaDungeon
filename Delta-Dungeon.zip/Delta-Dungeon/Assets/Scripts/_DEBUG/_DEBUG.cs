﻿/*
 * _DEBUG used by other scripts as such:
 * 
 * if( _DEBUG.debugDamage)
 *    Debug.Log("%s hits for %f damage", name, damage); 
 *    
 * (Here, name and damage are defined within the class)
 * 
 * Can print out info to the console for error checking.
 * Add anything you like in here, as we can all access this script
 * from anywhere in any other script - no need to attach this
 * to a GameObject.
 * 
 * Let's just make sure to turn everything off before
 * building (finishing) the game . . .
 * 
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class _DEBUG {

    #region debugging bools#

    public static bool
        debugDamage = false,
        debugHazards = false,
        debugPlayerSpeed = false;

    #endregion
}

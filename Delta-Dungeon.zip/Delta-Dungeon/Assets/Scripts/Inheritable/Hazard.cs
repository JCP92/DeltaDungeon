﻿/*
*   Parent class for objects that can harm Player.
*   Can be used for traps and whatnot.
*   
*/

using UnityEngine;
using System.Collections;

public class Hazard : MonoBehaviour
{
    #region Variables

    [Tooltip("Name of hazard")]
    public new string name;

    [Space]
    [Tooltip("Damage dealt by hazard")]
    [SerializeField]
    protected float damageDone;

    [Space]
    [Tooltip("Whether or not player can be harmed")]
    [SerializeField]
    protected bool canHarmPlayer;

    [Tooltip("Whether or not enemies can be harmed")]
    [SerializeField]
    protected bool canHarmEnemies;

    [Space]
    [Tooltip("Whether or not the object self-destructs after contact")]
    [SerializeField]
    protected bool aliveAfterContact;

    #endregion

    #region Constructor

    /// <summary>
    /// Default constructor which gives no name
    /// </summary>
    public Hazard()
    {
        // Default to no name if inheriting hazards leave a name out
        name = "noNameGiven";
    }

    #endregion

    #region Damage methods

    /// <summary>
    /// Do some damage to the enemy
    /// </summary>
    protected void damageEnemy(Collider other)
    {
        // Get enemy controlling script, deal damage through there
    }


    protected void damageHazard()
    {
        if (!aliveAfterContact)
        {
            // Add death stuff here
        }
    }

    /// <summary>
    /// Do some damage to the player
    /// </summary>
    protected void damagePlayer(Collider other)
    {
        // Get player controlling script, deal damage through there
    }

    #endregion


    // Check for player/Enemy getting hit
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (canHarmPlayer)
                damagePlayer(other);

            if (_DEBUG.debugHazards)
                Debug.Log("Hazard: Player hit by %s" + name);

            damageHazard();
        }
        else if (other.CompareTag("Enemy")){

            if (canHarmEnemies)
                damageEnemy(other);

            if (_DEBUG.debugHazards)
                Debug.Log("Hazard: Enemy hit by %s" + name);

            damageHazard();
        }
    }

}
